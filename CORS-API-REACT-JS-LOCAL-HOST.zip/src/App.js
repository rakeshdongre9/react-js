import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://api.kankuapp.com:8080/');
        setData(response.data);
      } catch (error) {
        console.error('API request failed:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h1>My React App</h1>
      {data && <pre>{JSON.stringify(data, null, 2)}</pre>}
    </div>
  );
}

export default App;